package com.cstest.IndexTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IndexTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(IndexTestApplication.class, args);
	}

}
