package com.cstest.IndexTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IndexTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
